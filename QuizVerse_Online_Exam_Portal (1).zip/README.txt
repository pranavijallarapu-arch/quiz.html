QUIZVERSE - ONLINE QUIZ PORTAL
================================

FILES
-----
index.html     -> Home, Login and Signup
admin.html     -> Admin exam creation dashboard
student.html   -> Student exam dashboard
style.css      -> Responsive Bootstrap/custom animation styles
app.js         -> Login, signup and local storage logic

HOW TO RUN
----------
1. Extract the ZIP.
2. Open index.html in Chrome, Edge, Firefox, or another modern browser.
3. Bootstrap is loaded from a CDN, so internet is recommended for the Bootstrap styling.

ROLES
-----
ADMIN:
- Sign up using Admin role.
- Create, edit and delete exams.
- Add questions, 4 options, and select the correct answer.
- Demo login: username = admin, password = admin123

STUDENT:
- Sign up using Student role.
- Enter a full name.
- The site automatically creates the username as:
      08 + Name
  Example: name Rahul -> username 08Rahul
- Password is automatically the same as username:
      username: 08Rahul
      password: 08Rahul

IMPORTANT
---------
This is a front-end demo. Accounts and exams are stored in the browser's localStorage.
It is suitable for a project/demo, but real exams need a backend/database and secure
password authentication before production use.
