let authMode="login", selectedRole="student";
const modal = new bootstrap.Modal(document.getElementById("authModal"));
const usersKey="quizverse_users";
const examsKey="quizverse_exams";

function getUsers(){return JSON.parse(localStorage.getItem(usersKey)||"[]")}
function saveUsers(u){localStorage.setItem(usersKey,JSON.stringify(u))}
function getExams(){return JSON.parse(localStorage.getItem(examsKey)||"[]")}
function saveExams(e){localStorage.setItem(examsKey,JSON.stringify(e))}

function openAuth(mode="login", role="student"){
  authMode=mode; selectedRole=role;
  document.getElementById("authTitle").textContent=mode==="login"?"Login":"Create Account";
  document.getElementById("authSubmit").textContent=mode==="login"?"Login":"Sign Up";
  document.getElementById("nameWrap").classList.toggle("d-none",mode==="login");
  document.getElementById("adminExtra").classList.toggle("d-none",role!=="admin");
  document.getElementById("switchText").textContent=mode==="login"?"Don't have an account?":"Already have an account?";
  document.querySelector("#authModal .btn-link").textContent=mode==="login"?"Sign up":"Login";
  setRole(role); clearMessage(); modal.show();
}
function switchAuth(){openAuth(authMode==="login"?"signup":"login",selectedRole)}
function setRole(role){
 selectedRole=role;
 document.querySelectorAll(".role-btn").forEach(b=>b.classList.toggle("active",b.dataset.role===role));
 document.getElementById("adminExtra").classList.toggle("d-none",role!=="admin");
 document.getElementById("studentHint").classList.toggle("d-none",role!=="student");
 document.getElementById("passwordHint").textContent=role==="student"?"For students, password is the same as username.":"Choose a secure password.";
}
function clearMessage(){document.getElementById("authMessage").innerHTML=""}
function message(txt,type="info"){document.getElementById("authMessage").innerHTML=`<div class="alert alert-${type} py-2">${txt}</div>`}

document.getElementById("authForm").addEventListener("submit",e=>{
 e.preventDefault();
 const name=document.getElementById("fullName").value.trim();
 let username=document.getElementById("username").value.trim();
 let password=document.getElementById("password").value;
 if(selectedRole==="student" && authMode==="signup"){
   const clean=name.replace(/[^a-zA-Z0-9]/g,"");
   if(!name){message("Please enter your full name.","warning");return}
   username="08"+clean;
   password=username;
   document.getElementById("username").value=username;
   document.getElementById("password").value=password;
 }
 if(!username||!password){message("Please fill all required fields.","warning");return}
 const users=getUsers();
 if(authMode==="signup"){
   if(users.some(u=>u.username.toLowerCase()===username.toLowerCase())){message("Username already exists.","danger");return}
   users.push({name:name||username,username,password,role:selectedRole,email:document.getElementById("email").value.trim()});
   saveUsers(users); message(`Account created! Your username is <b>${username}</b> and password is <b>${password}</b>.`,"success");
   document.getElementById("authForm").classList.add("success-pop");
   setTimeout(()=>openAuth("login",selectedRole),1000);
 }else{
   let user=users.find(u=>u.username===username&&u.password===password&&u.role===selectedRole);
   // Demo admin account
   if(selectedRole==="admin"&&username==="admin"&&password==="admin123") user={name:"Administrator",username:"admin",role:"admin"};
   if(!user){document.getElementById("authForm").classList.add("shake");setTimeout(()=>document.getElementById("authForm").classList.remove("shake"),400);message("Invalid username, password, or role.","danger");return}
   localStorage.setItem("quizverse_current",JSON.stringify(user));
   window.location.href=selectedRole==="admin"?"admin.html":"student.html";
 }
});
